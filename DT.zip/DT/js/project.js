var responsiveHelper = undefined;
var breakpointDefinition = {
    tablet: 1024,
    phone : 480
}; 
var Table, table = $(tableId);
$(document).ready(function() {
	Table = table.DataTable({
		fixedColumns: true,
        lengthChange: true,
        lengthMenu: [[10, 50, 100, 200, -1], [10, 50, 100, 200, "All"]],
        info: true,
        autoWidth: false,
        bJQueryUI: true,
        scrollX: true,
        preDrawCallback: function() {
            if (!responsiveHelper) {
                responsiveHelper = new ResponsiveDatatablesHelper(table, breakpointDefinition);
            }
        },
        rowCallback: function(nRow) {
            responsiveHelper.createExpandIcon(nRow);
        },
        drawCallback: function(oSettings) {
            responsiveHelper.respond();
        },
	}); 
});

